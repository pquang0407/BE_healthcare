package com.nckh.yte.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.util.UUID; // Thêm import

/**
 * Information entity to store additional profile data for a user.
 * This table stores one record per user with basic profile fields such as
 * full name, role, birthday and sex.  The {@code user} relationship is
 * marked as unique to ensure one-to-one mapping between a user and their
 * information record.
 */
@Entity
@Table(name = "information")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Information {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID) // Sửa strategy
    private UUID id; // Sửa Long thành UUID

    @OneToOne(optional = false)
    @JoinColumn(name = "user_id", referencedColumnName = "id", unique = true)
    private User user;

    @Column(nullable = false, length = 200)
    private String fullName;

    @Column(nullable = false, length = 50)
    private String role;

    @Column(nullable = false)
    private LocalDate birthday;

    @Column(nullable = false, length = 20)
    private String sex;

    /**
     * Department (khoa) where the user works or receives treatment. Examples include
     * "Khoa Nội", "Khoa Ngoại", "Khoa Sản", v.v. This field is optional but required when
     * collecting full information from doctors, nurses or patients.
     */
    @Column(name = "department", length = 100)
    private String department;
}