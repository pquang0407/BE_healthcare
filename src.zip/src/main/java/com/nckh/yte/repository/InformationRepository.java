package com.nckh.yte.repository;

import com.nckh.yte.entity.Information;
import com.nckh.yte.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.UUID;

/**
 * Repository for {@link Information} entity. Provides CRUD operations and
 * convenience lookup by user id.
 */
public interface InformationRepository extends JpaRepository<Information, UUID> {
    Optional<Information> findByUser_Id(UUID userId);

    Optional<Information> findByUser(User user);
}