package com.nckh.yte.controller;

import com.nckh.yte.entity.Information;
import com.nckh.yte.entity.User;
import com.nckh.yte.repository.InformationRepository;
import com.nckh.yte.repository.UserRepository;
import com.nckh.yte.security.UserDetailsImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Map;

/**
 * REST controller exposing endpoints for retrieving and updating the current
 * user's personal information (full name, role, birthday and sex).
 *
 * All endpoints require authentication.  Only users with role ADMIN, DOCTOR,
 * NURSE or PATIENT can access them.  The user's role is derived from the
 * authenticated principal, not from the request body.
 */
@RestController
@RequestMapping("/api/info")
@CrossOrigin(origins = "*")
@RequiredArgsConstructor
public class InfoController {

    private final InformationRepository infoRepo;
    private final UserRepository userRepo;

    /**
     * Payload to create/update personal information. Includes full name, birthday (yyyy-MM-dd), sex and
     * department. The department represents the working or treatment department (khoa) selected by
     * doctors, nurses or patients.
     */
    record InfoRequest(String fullName, String birthday, String sex, String department) {}

    /**
     * Return the {@link Information} record for the currently authenticated user.
     * If no record exists, {@code null} is returned.
     */
    @GetMapping("/me")
    public ResponseEntity<?> getMyInfo(@org.springframework.security.core.annotation.AuthenticationPrincipal UserDetailsImpl auth) {
        var opt = infoRepo.findByUser_Id(auth.getId());
        return ResponseEntity.ok(opt.orElse(null));
    }

    /**
     * Create or update the {@link Information} record for the currently authenticated user.
     * The user's role is taken from the JWT and cannot be overridden.  If the information
     * record does not exist, it will be created; otherwise it will be updated.  The fullName,
     * birthday and sex fields are required.  Birthday must be an ISO-8601 date (yyyy-MM-dd).
     */
    @PostMapping("/me")
    public ResponseEntity<?> upsertMyInfo(@RequestBody InfoRequest req,
                                          @org.springframework.security.core.annotation.AuthenticationPrincipal UserDetailsImpl auth) {
        try {
            if (req == null || req.birthday() == null || req.sex() == null || req.fullName() == null || req.department() == null) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(Map.of("message", "Thiếu thông tin bắt buộc"));
            }
            User user = userRepo.findById(auth.getId())
                    .orElseThrow(() -> new IllegalStateException("User not found"));
            Information info = infoRepo.findByUser(user)
                    .orElseGet(Information::new);
            info.setUser(user);
            info.setFullName(req.fullName().trim());
            info.setRole(auth.getRoleName());
            info.setBirthday(LocalDate.parse(req.birthday()));
            info.setSex(req.sex().trim().toUpperCase());
            info.setDepartment(req.department().trim());
            infoRepo.save(info);
            return ResponseEntity.ok(Map.of("message", "Đã lưu thông tin"));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("message", "Lỗi server: " + e.getMessage()));
        }
    }
}