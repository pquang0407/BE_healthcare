package com.nckh.yte.controller;

import com.nckh.yte.DrugApiConfig;
import com.nckh.yte.GeminiConfig;
import lombok.RequiredArgsConstructor;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.*;

@RestController
@RequestMapping("/api/ai")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class DrugInfoDetailedController {

    private final GeminiConfig geminiConfig;
    private final DrugApiConfig drugApiConfig;
    private final RestTemplate restTemplate;

    @PostMapping("/drug-info-full")
    public ResponseEntity<Object> getDrugInfoFull(@RequestBody Map<String, String> body) {
        String drugName = body != null ? body.get("drug") : null;
        if (drugName == null || drugName.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Missing 'drug' field!"));
        }

        try {
            JSONArray results = fetchOpenFdaResults(drugName, 3);
            if (results == null || results.isEmpty()) {
                return ResponseEntity.ok(Map.of(
                        "items", Collections.emptyList(),
                        "message", "Không tìm thấy dữ liệu cho thuốc này."
                ));
            }

            List<Map<String, Object>> items = new ArrayList<>();
            for (int i = 0; i < results.length(); i++) {
                JSONObject entry = results.getJSONObject(i);
                JSONObject fda = entry.optJSONObject("openfda");

                String englishName = extractFieldArray(fda, "brand_name", "Unknown");
                String manufacturer = extractFieldArray(fda, "manufacturer_name", "Không rõ");

                String indications = joinStringArray(entry.optJSONArray("indications_and_usage"));
                String warnings = joinStringArray(entry.optJSONArray("warnings_and_cautions"));
                String sideEffects = joinStringArray(entry.optJSONArray("adverse_reactions"));
                String pregnancy = joinStringArray(entry.optJSONArray("pregnancy"));

                String englishText =
                        "Tên thuốc: " + englishName + "\n" +
                        "Công dụng: " + (indications.isBlank() ? "Không có" : indications) + "\n" +
                        "Cảnh báo: " + (warnings.isBlank() ? "Không có" : warnings) + "\n" +
                        "Tác dụng phụ: " + (sideEffects.isBlank() ? "Không có" : sideEffects) + "\n" +
                        "Phụ nữ mang thai: " + (pregnancy.isBlank() ? "Không có" : pregnancy);

                // Gọi Gemini và làm sạch text
                String summaryVi = summarizeToVNTextWithGemini(englishText, englishName);

                Map<String, Object> item = new LinkedHashMap<>();
                item.put("Tên thuốc", englishName);
                item.put("Hãng sản xuất", manufacturer);
                item.put("Tóm tắt bác sĩ", summaryVi);
                items.add(item);
            }

            return ResponseEntity.ok(Map.of("items", items));

        } catch (HttpStatusCodeException ex) {
            return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(Map.of(
                    "error", "Upstream HTTP error: " + ex.getStatusCode(),
                    "detail", ex.getResponseBodyAsString()
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Unhandled error: " + e.getMessage()));
        }
    }

    private JSONArray fetchOpenFdaResults(String drugName, int limit) {
        String q = quoted(drugName);
        String searchExpr = "openfda.generic_name:" + q + " OR openfda.brand_name:" + q;

        ResponseEntity<String> resp;
        try {
            resp = restTemplate.getForEntity(buildFdaUri(searchExpr, limit, true), String.class);
        } catch (HttpStatusCodeException ex) {
            String body = ex.getResponseBodyAsString();
            if (ex.getStatusCode().value() == 403 && body != null && body.contains("API_KEY_INVALID")) {
                resp = restTemplate.getForEntity(buildFdaUri(searchExpr, limit, false), String.class);
            } else {
                throw ex;
            }
        }

        if (resp == null || !resp.getStatusCode().is2xxSuccessful() || resp.getBody() == null) {
            return null;
        }

        JSONObject root = new JSONObject(resp.getBody());
        return root.optJSONArray("results");
    }

    private URI buildFdaUri(String searchExpr, int limit, boolean withKey) {
        UriComponentsBuilder b = UriComponentsBuilder
                .fromHttpUrl(trimTrailingSlash(drugApiConfig.getBaseurl()))
                .path("/drug/label.json")
                .queryParam("search", searchExpr)
                .queryParam("limit", limit);
        if (withKey && drugApiConfig.getApikey() != null && !drugApiConfig.getApikey().isBlank()) {
            b.queryParam("api_key", drugApiConfig.getApikey());
        }
        return b.build().encode().toUri();
    }

    private static String joinStringArray(JSONArray arr) {
        if (arr == null || arr.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < arr.length(); i++) {
            String v = arr.optString(i, "").trim();
            if (!v.isEmpty()) {
                if (sb.length() > 0) sb.append(" ");
                sb.append(v);
            }
        }
        return sb.toString();
    }

    private static String extractFieldArray(JSONObject fda, String key, String defaultVal) {
        if (fda == null || !fda.has(key)) return defaultVal;
        JSONArray arr = fda.optJSONArray(key);
        if (arr == null || arr.isEmpty()) return defaultVal;
        List<String> list = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) {
            String val = arr.optString(i, "");
            if (!val.isBlank()) list.add(val);
        }
        return list.isEmpty() ? defaultVal : String.join(", ", list);
    }

    private String summarizeToVNTextWithGemini(String englishText, String drugName) {
        if (englishText == null || englishText.isBlank()) {
            return "(Không có nội dung)";
        }

        URI geminiUri = UriComponentsBuilder
                .fromHttpUrl(trimTrailingSlash(geminiConfig.getBaseurl()))
                .path("/" + trimLeadingSlash(geminiConfig.getModel()) + ":generateContent")
                .queryParam("key", geminiConfig.getApikey())
                .build()
                .toUri();

        String prompt =
                "Bạn là bác sĩ trợ lý trong hệ thống y tế. " +
                "Hãy tóm tắt ngắn gọn, rõ ràng và dễ hiểu bằng tiếng Việt cho bệnh nhân dựa trên nội dung sau. " +
                "Trình bày theo các mục: Công dụng chính, Liều dùng, Cảnh báo, Tác dụng phụ, và Lưu ý cho phụ nữ mang thai hoặc cho con bú.\n\n" +
                "Dữ liệu tiếng Anh về thuốc \"" + drugName + "\":\n" + englishText;

        Map<String, Object> geminiBody = Map.of(
                "contents", List.of(Map.of("parts", List.of(Map.of("text", prompt))))
        );

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(List.of(MediaType.APPLICATION_JSON));
        HttpEntity<Map<String, Object>> req = new HttpEntity<>(geminiBody, headers);

        try {
            String raw = restTemplate.postForObject(geminiUri, req, String.class);
            if (raw == null || raw.isBlank()) {
                return "(Không có nội dung)";
            }
            JSONObject g = new JSONObject(raw);
            String text = extractGeminiText(g);
            return cleanText(text);
        } catch (HttpStatusCodeException ex) {
            return "(Lỗi Gemini HTTP " + ex.getStatusCode() + ")";
        } catch (Exception e) {
            return "(Lỗi khi gọi Gemini: " + e.getMessage() + ")";
        }
    }

    private static String extractGeminiText(JSONObject geminiJson) {
        if (geminiJson == null) return null;
        JSONArray cands = geminiJson.optJSONArray("candidates");
        if (cands == null || cands.isEmpty()) return null;
        JSONObject cand0 = cands.optJSONObject(0);
        if (cand0 == null) return null;
        JSONObject content = cand0.optJSONObject("content");
        if (content == null) return null;
        JSONArray parts = content.optJSONArray("parts");
        if (parts == null || parts.isEmpty()) return null;
        JSONObject part0 = parts.optJSONObject(0);
        if (part0 == null) return null;
        return part0.optString("text", null);
    }

    // === Utility methods ===

    /** Xóa hoàn toàn ký tự đặc biệt, giữ nguyên chữ và số **/
    private static String cleanText(String s) {
        if (s == null) return "(Không có nội dung)";
        return s.replaceAll("[^\\p{L}\\p{N}\\s.,:;()\\-–/]", "")  // chỉ giữ chữ, số, khoảng trắng và dấu cơ bản
                .replaceAll("\\s{2,}", " ")                      // gom nhiều space lại thành 1
                .trim();
    }

    private static String quoted(String s) {
        if (s == null) return "\"\"";
        return "\"" + s.replace("\"", "") + "\"";
    }

    private static String trimTrailingSlash(String s) {
        if (s == null) return "";
        return s.endsWith("/") ? s.substring(0, s.length() - 1) : s;
    }

    private static String trimLeadingSlash(String s) {
        if (s == null) return "";
        return s.startsWith("/") ? s.substring(1) : s;
    }
}
